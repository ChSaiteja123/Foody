from django.db import models

# Create your models here.
class order(models.Model):
    order_id = models.AutoField(primary_key=True)
    customer_name = models.CharField(max_length=255)
    product_name = models.CharField(max_length=255)
    quantity = models.IntegerField()
    order_date = models.DateTimeField(auto_now_add=True)

class items(models.Model):
    item_id = models.AutoField(primary_key=True)
    order = models.ForeignKey(order, on_delete=models.CASCADE)
    product_name = models.CharField(max_length=255)
    quantity = models.IntegerField()
    price = models.DecimalField(max_digits=10, decimal_places=2)

class customer(models.Model):
    customer_id = models.AutoField(primary_key=True)
    customer_name = models.CharField(max_length=255)
    email = models.EmailField(max_length=255)
    phone = models.CharField(max_length=20)

class payment(models.Model):
    payment_id = models.AutoField(primary_key=True)
    order = models.ForeignKey(order, on_delete=models.CASCADE)
    payment_date = models.DateTimeField(auto_now_add=True)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    payment_method = models.CharField(max_length=50)

class shipment(models.Model):
    shipment_id = models.AutoField(primary_key=True)
    order = models.ForeignKey(order, on_delete=models.CASCADE)
    shipment_date = models.DateTimeField(auto_now_add=True)
    delivery_date = models.DateTimeField(null=True, blank=True)
    status = models.CharField(max_length=50)

class employee(models.Model):
    employee_id = models.AutoField(primary_key=True)
    employee_name = models.CharField(max_length=255)
    position = models.CharField(max_length=100)
    hire_date = models.DateTimeField(auto_now_add=True)

class owner(models.Model):
    owner_id = models.AutoField(primary_key=True)
    owner_name = models.CharField(max_length=255)
    contact_info = models.CharField(max_length=255)

class total(models.Model):
    customer = models.ForeignKey(customer, on_delete=models.CASCADE)
    order = models.ForeignKey(order, on_delete=models.CASCADE)
    total_amount = models.DecimalField(max_digits=10, decimal_places=2)

    def __str__(self):
        return f"Total for Order {self.order.order_id}: {self.total_amount}"