from django.shortcuts import render

# Create your views here.
def home(request):
    return render(request, "home.html")

def order(request):
    orders = order.objects.all()
    
    return render(request, "order.html", {"orders": orders})

def payment(request):
    payments = payment.objects.all()
    return render(request, "payment.html", {"payments": payments})

def shipment(request):
    shipments = shipment.objects.all()
    return render(request, "shipment.html", {"shipments": shipments})

def employee(request):
    employees = employee.objects.all()
    return render(request, "employee.html", {"employees": employees})

def owner(request):
    owners = owner.objects.all()
    return render(request, "owner.html", {"owners": owners})

def total(request):
    totals = total.objects.all()
    return render(request, "total.html", {"totals": totals})


def product(request):

    items = items.objects.all()


    return render(request, "product.html", {"items": items})

def customer(request):
    customers = customer.objects.all()
    return render(request, "customer.html", {"customers": customers})