from django.contrib import admin

from . import models
from .models import order, items, customer, payment, shipment, employee, owner, total

# Register your models here.
class orderAdmin(admin.ModelAdmin):
    list_display = ('order_id', 'customer_name', 'product_name', 'quantity', 'order_date')
admin.site.register(order, orderAdmin)

class itemsAdmin(admin.ModelAdmin):
    list_display = ('item_id', 'order', 'product_name', 'quantity', 'price')
admin.site.register(items, itemsAdmin)

class customerAdmin(admin.ModelAdmin):
    list_display = ('customer_id', 'customer_name', 'email', 'phone')
admin.site.register(customer, customerAdmin)

class paymentAdmin(admin.ModelAdmin):
    list_display = ('payment_id', 'order', 'payment_date', 'amount', 'payment_method')
admin.site.register(payment, paymentAdmin)

class shipmentAdmin(admin.ModelAdmin):
    list_display = ('shipment_id', 'order', 'shipment_date', 'delivery_date', 'status')
admin.site.register(shipment, shipmentAdmin)

class employeeAdmin(admin.ModelAdmin):
    list_display = ('employee_id', 'employee_name', 'position', 'hire_date')
admin.site.register(employee, employeeAdmin)

class ownerAdmin(admin.ModelAdmin):
    list_display = ('owner_id', 'owner_name', 'contact_info')
admin.site.register(owner, ownerAdmin)

class totalAdmin(admin.ModelAdmin):
    list_display = ('customer', 'order', 'total_amount')
admin.site.register(total, totalAdmin)